入力されたMinecraftのreplaceitemコマンドをitemコマンドに変換するJavaアプリケーションです。
使用するには同じ階層の　run.cmd を実行してください。
  
使い方
  1.ウィンドウ上部の入力欄にコマンドを入力
  2.ウィンドウ中央で入力コマンドの形式を設定
  3.NBT書き換えの設定
    (これにチェックを入れた場合、コマンドの中のNBTについても処理します。
     NameやLore、その他のテキストについても処理を行う為、注意して使用してください。)
  4.ウィンドウ下部の出力欄からコマンドをコピー

改造、二次配布はご遠慮ください。
内部の処理をしているクラスはこちらで配布しています。
https://github.com/Maple-32768/Java_Applications/blob/main/item_commands_come_on/src/ConvertToItem.java

作者Twitter : https://twitter.com/maple_osg